"""Run from project root: python tests/smoke.py"""
import datetime
import http.cookiejar
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
with socket.socket() as s:
    s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
code='SETKA-SMOKE-TEST'
folder=tempfile.TemporaryDirectory()
proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,
    env={**os.environ,'SETKA_DATA_DIR':folder.name,'SETKA_ADMIN_CODE':code,'HOST':'127.0.0.1','PORT':str(port)},stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
base=f'http://127.0.0.1:{port}'
jar=http.cookiejar.CookieJar();client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar));csrf=''
def call(path,body=None):
    headers={};data=None
    if body is not None:
        data=json.dumps(body).encode(); headers={'Content-Type':'application/json'}
        if csrf:headers['X-CSRF-Token']=csrf
    try:
        with client.open(urllib.request.Request(base+path,data=data,headers=headers),timeout=4) as r:
            return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code,json.loads(e.read())
try:
    for _ in range(50):
        try:urllib.request.urlopen(base,timeout=.4);break
        except Exception:time.sleep(.1)
    else:raise RuntimeError('Server failed to start')
    assert call('/api/admin/dashboard')[0]==403
    assert call('/api/admin/login',{'code':'wrong'})[0]==401
    status,data=call('/api/admin/login',{'code':code});assert status==200;csrf=data['csrf']
    now=datetime.datetime.now(ZoneInfo('Europe/Moscow'))
    day=(now-datetime.timedelta(days=1)).date()
    assert call('/api/admin/settings',{'season_name':'Тест','season_start':(day-datetime.timedelta(days=1)).isoformat(),'season_end':(day+datetime.timedelta(days=10)).isoformat()})[0]==200
    status,d=call('/api/admin/players',{'nickname':'Проверка','phone':'+79990001234','pass_paid':True,'consent_confirmed':True});assert status==201
    pid=d['player']['id'];token=d['player']['link_token']
    assert 'phone' not in call('/api/public/player/'+token)[1]['player']
    night=day.isoformat()+'T22:15'
    assert call('/api/admin/purchase',{'player_id':pid,'amount':399,'occurred_at':night})[0]==400
    assert call('/api/admin/purchase',{'player_id':pid,'amount':400,'occurred_at':day.isoformat()+'T15:00'})[0]==400
    for i in range(1,31):
        status,res=call('/api/admin/purchase',{'player_id':pid,'amount':400,'occurred_at':night,'receipt':f'TEST-{i}'})
        assert status==201,(i,status,res)
        assert res['step']==i
    assert call('/api/admin/player/'+str(pid))[1]['progress']==30
    p=call('/api/admin/player/'+str(pid))[1]
    assert len(p['rewards'])==34
    purchase_id=p['history'][0]['id']
    assert call('/api/admin/purchase/cancel',{'player_id':pid,'purchase_id':purchase_id,'reason':'Исправление чека'})[0]==200
    assert call('/api/admin/player/'+str(pid))[1]['progress']==29
    assert call('/api/admin/purchase',{'player_id':pid,'amount':500,'occurred_at':night,'receipt':'TEST-30'})[0]==201
    assert call('/api/admin/player/'+str(pid))[1]['progress']==30
    reward=call('/api/admin/player/'+str(pid))[1]['rewards'][0]
    assert call('/api/admin/reward',{'reward_id':reward['id'],'handed':True})[0]==200
    assert call('/api/admin/logout',{})[0]==200
    assert call('/api/admin/dashboard')[0]==403
    print('PASS: login, access, player, phone privacy, 30 purchases, prizes, cancellation, reward delivery, logout')
finally:
    proc.terminate();proc.wait(timeout=4)
    folder.cleanup()
